
-- Data Cleansing NSW_Property File_Round 1(2)

-- Step 2: SQL query applied to observe features of the field - 'state'
SELECT DISTINCT state
FROM [Property Data Engineering].dbo.[NSW_Property_original_data(Do Not Truncate)]
ORDER BY state

-- Conclusition: The 'state' field contains only two unique values �� 'NEW SOUTH WALES_NSW' and 'New South Wales'.
--               All values must be standardized to 'New South Wales' for consistency.

-------------------------------------------------------------------------------------------------------------------------------

-- Step 3 : SQL query applied to observe features of the field - 'city/town'
SELECT DISTINCT [city/town]
FROM [Property Data Engineering].dbo.[NSW_Property_original_data(Do Not Truncate)]
ORDER BY [city/town]

--  Conclusion: All city names in the 'city/town' field are currently presented in uppercase letters;
--              These entries must be standardized by converting each city name to title case,
--              where the first letter of each word is capitalized and the remaining letters are in lowercase
--              (e.g. SHOAL BAY -> Shoal Bay)

-------------------------------------------------------------------------------------------------------------------------------

-- Step 4: SQL query applied to observe features of the field - 'property_median_value'
SELECT COUNT(*)
FROM [Property Data Engineering].dbo.[NSW_Property_original_data(Do Not Truncate)] AS nsw
WHERE nsw.property_median_value=0
