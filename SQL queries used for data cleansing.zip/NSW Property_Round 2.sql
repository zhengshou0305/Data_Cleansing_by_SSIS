
-- Step 2: SQL query used to observe the features of duplicated data 
SELECT 
    nsw.state,
    nsw.[city/town],
    nsw.suburb,
	COUNT(*) AS count_amount
FROM 
    [Property Data Engineering].dbo.[NSW Property_data cleansing_Round 1(2)_end] AS nsw
GROUP BY 
    nsw.state, nsw.[city/town], nsw.suburb
HAVING 
    COUNT(*) > 1
ORDER BY 
    nsw.state, nsw.[city/town], nsw.suburb;

-- Conclusion: Post structural data cleansing, 62 instances of duplicate records were 
--             detected within the NSW_Property dataset. For each identified group of duplicates, 
--             only the first occurrence was preserved, while all subsequent entries were systematically 
--             removed to ensure data integrity.